// ============================================================
//  Kujt i ngec Kerri — Server (Node.js + WebSocket)
//  server.js
// ============================================================
const express = require('express');
const { WebSocketServer, WebSocket } = require('ws');
const { v4: uuidv4 } = require('uuid');
const http = require('http');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;

// ─── Ruajtja e dhomave dhe lojtarëve ─────────────────────────
// rooms[roomCode] = { code, players, hands, activeIdx, phase, kerriType }
const rooms = {};
// clients[ws] = { playerId, roomCode, name }
const clients = new WeakMap();

// ─── Ndërtimi i kuvertës ──────────────────────────────────────
const RANKS = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
const SUITS = ['♠','♣','♥','♦'];
const KERRI_CONFIGS = {
  joker: { rank: '★', suit: '★' },
  queen: { rank: 'Q', suit: '♠' },
  ace:   { rank: 'A', suit: '♥' },
};

function buildDeck(kerriType) {
  const cfg = KERRI_CONFIGS[kerriType] || KERRI_CONFIGS.joker;
  const deck = [];
  SUITS.forEach(suit => {
    RANKS.forEach(rank => {
      if (cfg.rank === rank && cfg.suit === suit) return;
      deck.push({ rank, suit, isKerri: false, id: rank + suit });
    });
  });
  deck.push({ rank: cfg.rank, suit: cfg.suit, isKerri: true, id: 'KERRI' });
  return deck;
}

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function autoRemovePairs(hand) {
  let changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < hand.length; i++) {
      if (hand[i].isKerri) continue;
      for (let j = i + 1; j < hand.length; j++) {
        if (!hand[j].isKerri && hand[i].rank === hand[j].rank) {
          hand.splice(j, 1); hand.splice(i, 1);
          changed = true; break;
        }
      }
      if (changed) break;
    }
  }
}

// ─── Gjenero kod dhome 4-shkronjësh ──────────────────────────
function makeRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return rooms[code] ? makeRoomCode() : code;
}

// ─── Dërgo mesazh tek një ws ──────────────────────────────────
function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}

// ─── Dërgo tek të gjithë lojtarët e dhomës ───────────────────
function broadcast(room, data, excludeWs = null) {
  room.players.forEach(p => {
    if (p.ws !== excludeWs) send(p.ws, data);
  });
}

// ─── Dërgo gjendjen e lojës (secili sheh vetëm letrat e veta) ─
function sendGameState(room) {
  room.players.forEach(player => {
    // Ndërtojmë pamjen për këtë lojtar
    const opponents = room.players
      .filter(p => p.id !== player.id)
      .map(p => ({
        id:       p.id,
        name:     p.name,
        cardCount: room.hands[p.id] ? room.hands[p.id].length : 0,
        isActive: room.activeIdx === room.players.findIndex(x => x.id === p.id),
        isOut:    room.hands[p.id] && room.hands[p.id].length === 0,
      }));

    const myHand = room.hands[player.id] || [];
    const activePlayer = room.players[room.activeIdx];
    const isMyTurn = activePlayer && activePlayer.id === player.id;

    // Nga kush mund të marrë ky lojtar (lojtari djathtas me letra)
    let drawFromId = null;
    if (isMyTurn) {
      const myIdx = room.players.findIndex(p => p.id === player.id);
      for (let d = 1; d < room.players.length; d++) {
        const t = (myIdx + d) % room.players.length;
        const tp = room.players[t];
        if (room.hands[tp.id] && room.hands[tp.id].length > 0) {
          drawFromId = tp.id;
          break;
        }
      }
    }

    send(player.ws, {
      type:        'game_state',
      phase:       room.phase,
      myHand,
      opponents,
      activePlayerId: activePlayer ? activePlayer.id : null,
      isMyTurn,
      drawFromId,
      roomCode:    room.code,
      players:     room.players.map(p => ({ id: p.id, name: p.name })),
      log:         room.log.slice(0, 6),
    });
  });
}

function sendLobbyState(room) {
  broadcast(room, {
    type:    'lobby_state',
    roomCode: room.code,
    players: room.players.map(p => ({ id: p.id, name: p.name, isHost: p.isHost })),
    phase:   room.phase,
  });
}

// ─── Fillo lojën ──────────────────────────────────────────────
function startGame(room) {
  room.phase = 'playing';
  room.log   = [];

  const deck = shuffle(buildDeck(room.kerriType));
  room.hands = {};
  room.players.forEach(p => room.hands[p.id] = []);
  deck.forEach((card, i) => {
    const p = room.players[i % room.players.length];
    room.hands[p.id].push(card);
  });
  room.players.forEach(p => autoRemovePairs(room.hands[p.id]));

  room.activeIdx = 0;
  room.log.push(`Loja filloi me ${room.players.length} lojtarë!`);
  sendGameState(room);
}

// ─── Kontrollo fund loje ──────────────────────────────────────
function checkGameOver(room) {
  const alive = room.players.filter(p => room.hands[p.id] && room.hands[p.id].length > 0);
  if (alive.length > 1) return false;

  room.phase = 'gameover';
  let loserId = null;
  room.players.forEach(p => {
    if (room.hands[p.id] && room.hands[p.id].some(c => c.isKerri)) loserId = p.id;
  });
  if (!loserId && alive.length === 1) loserId = alive[0].id;

  const loserName = loserId ? room.players.find(p => p.id === loserId)?.name : '???';
  room.log.unshift(`Loja mbaroi! ${loserName} i ngeci Kerri!`);

  broadcast(room, {
    type:    'game_over',
    loserId,
    loserName,
    results: room.players.map(p => ({
      id:       p.id,
      name:     p.name,
      hasKerri: room.hands[p.id]?.some(c => c.isKerri) || false,
      cardCount: room.hands[p.id]?.length || 0,
    })),
  });
  return true;
}

// ─── Kalon radha ──────────────────────────────────────────────
function advanceTurn(room) {
  let safety = 0;
  do {
    room.activeIdx = (room.activeIdx + 1) % room.players.length;
    safety++;
  } while (
    room.hands[room.players[room.activeIdx].id]?.length === 0 &&
    safety < room.players.length
  );
  sendGameState(room);
}

// ─── WebSocket events ─────────────────────────────────────────
wss.on('connection', ws => {
  const playerId = uuidv4();
  clients.set(ws, { playerId });

  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    const clientInfo = clients.get(ws);

    switch (msg.type) {

      // Krijo dhomë të re
      case 'create_room': {
        const code = makeRoomCode();
        const room = {
          code,
          phase:     'lobby',
          kerriType: msg.kerriType || 'joker',
          players:   [],
          hands:     {},
          activeIdx: 0,
          log:       [],
        };
        rooms[code] = room;
        const player = { id: playerId, name: msg.name || 'Lojtar 1', ws, isHost: true };
        room.players.push(player);
        clientInfo.roomCode = code;
        clientInfo.name     = player.name;
        send(ws, { type: 'joined', playerId, roomCode: code, isHost: true });
        sendLobbyState(room);
        break;
      }

      // Bashkohu në dhomë ekzistuese
      case 'join_room': {
        const room = rooms[msg.roomCode?.toUpperCase()];
        if (!room) { send(ws, { type: 'error', message: 'Dhoma nuk u gjet!' }); break; }
        if (room.phase !== 'lobby') { send(ws, { type: 'error', message: 'Loja ka filluar tashmë!' }); break; }
        if (room.players.length >= 6) { send(ws, { type: 'error', message: 'Dhoma është plot (max 6)!' }); break; }

        const player = { id: playerId, name: msg.name || `Lojtar ${room.players.length + 1}`, ws, isHost: false };
        room.players.push(player);
        clientInfo.roomCode = room.code;
        clientInfo.name     = player.name;
        send(ws, { type: 'joined', playerId, roomCode: room.code, isHost: false });
        room.log.push(`${player.name} u bashkua.`);
        sendLobbyState(room);
        broadcast(room, { type: 'chat', text: `${player.name} u bashkua në lojë!`, system: true }, ws);
        break;
      }

      // Host fillon lojën
      case 'start_game': {
        const room = rooms[clientInfo.roomCode];
        if (!room) break;
        const host = room.players.find(p => p.id === playerId);
        if (!host?.isHost) { send(ws, { type: 'error', message: 'Vetëm hosti mund ta fillojë lojën.' }); break; }
        if (room.players.length < 2) { send(ws, { type: 'error', message: 'Duhen të paktën 2 lojtarë!' }); break; }
        startGame(room);
        break;
      }

      // Lojtari merr letër nga kundërshtari
      case 'draw_card': {
        const room = rooms[clientInfo.roomCode];
        if (!room || room.phase !== 'playing') break;
        const activePlayer = room.players[room.activeIdx];
        if (activePlayer.id !== playerId) { send(ws, { type: 'error', message: 'Nuk është radha jote!' }); break; }

        const fromPlayer = room.players.find(p => p.id === msg.fromPlayerId);
        if (!fromPlayer) break;
        const fromHand = room.hands[fromPlayer.id];
        if (!fromHand || fromHand.length === 0) break;

        // Verifiko se lojtari zgjedh kartën e saktë nga indeksi
        const cardIdx = msg.cardIndex;
        if (cardIdx === undefined || cardIdx < 0 || cardIdx >= fromHand.length) break;

        const card = fromHand.splice(cardIdx, 1)[0];
        room.hands[playerId].push(card);
        room.log.unshift(`${activePlayer.name} mori "${card.isKerri ? 'KERRI' : card.rank+card.suit}" nga ${fromPlayer.name}`);
        autoRemovePairs(room.hands[playerId]);

        if (checkGameOver(room)) break;
        advanceTurn(room);
        break;
      }

      // Chat
      case 'chat': {
        const room = rooms[clientInfo.roomCode];
        if (!room) break;
        const sender = room.players.find(p => p.id === playerId);
        broadcast(room, { type: 'chat', text: msg.text, sender: sender?.name || '?' });
        break;
      }
    }
  });

  ws.on('close', () => {
    const info = clients.get(ws);
    if (!info?.roomCode) return;
    const room = rooms[info.roomCode];
    if (!room) return;
    const pIdx = room.players.findIndex(p => p.id === info.playerId);
    if (pIdx !== -1) {
      const name = room.players[pIdx].name;
      room.players.splice(pIdx, 1);
      room.log.unshift(`${name} u largua.`);
      if (room.players.length === 0) {
        delete rooms[info.roomCode];
      } else {
        if (!room.players.some(p => p.isHost)) room.players[0].isHost = true;
        if (room.phase === 'lobby') sendLobbyState(room);
        else sendGameState(room);
      }
    }
  });
});

server.listen(PORT, () => console.log(`Kerri server duke punuar: http://localhost:${PORT}`));
