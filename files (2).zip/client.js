/* ============================================================
   Kujt i ngec Kerri — Klienti (client.js)
   ============================================================ */

// ─── Shteti i klientit ────────────────────────────────────────
let ws = null;
let myId       = null;
let myName     = '';
let roomCode   = null;
let isHost     = false;
let pendingDraw = null;   // { fromPlayerId, opponents } — kur hapet modali

const RED_SUITS = new Set(['♥','♦']);

// ─── WebSocket connection ─────────────────────────────────────
function connect(onOpen) {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}`);

  ws.onopen  = onOpen;
  ws.onmessage = e => handleMessage(JSON.parse(e.data));
  ws.onclose = () => {
    showError('home-error', 'Lidhja me serverin u ndërpre. Rifresko faqen.');
  };
  ws.onerror = () => {
    showError('home-error', 'Nuk mund të lidhemi me serverin.');
  };
}

function sendMsg(data) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}

// ─── Menaxhimi i mesazheve nga serveri ───────────────────────
function handleMessage(msg) {
  switch (msg.type) {

    case 'joined':
      myId   = msg.playerId;
      isHost = msg.isHost;
      roomCode = msg.roomCode;
      showPhase('lobby');
      break;

    case 'lobby_state':
      renderLobby(msg);
      break;

    case 'game_state':
      renderGame(msg);
      break;

    case 'game_over':
      renderGameOver(msg);
      break;

    case 'chat':
      appendChat(msg);
      break;

    case 'error':
      showError('home-error', msg.message);
      showError('create-error', msg.message);
      break;
  }
}

// ─── Ekrani Home ──────────────────────────────────────────────
function goCreate() {
  const name = document.getElementById('home-name').value.trim();
  if (!name) { showError('home-error', 'Shkruaj emrin tënd!'); return; }
  myName = name;
  hideError('home-error');
  showPhase('create');
}

function goJoin() {
  const name = document.getElementById('home-name').value.trim();
  const code = document.getElementById('home-code').value.trim().toUpperCase();
  if (!name) { showError('home-error', 'Shkruaj emrin tënd!'); return; }
  if (code.length !== 4) { showError('home-error', 'Kodi duhet të jetë 4 karaktere!'); return; }
  myName = name;
  hideError('home-error');
  connect(() => sendMsg({ type: 'join_room', name: myName, roomCode: code }));
}

// ─── Krijo dhomë ──────────────────────────────────────────────
function createRoom() {
  const kerriType = document.getElementById('create-kerri').value;
  connect(() => sendMsg({ type: 'create_room', name: myName, kerriType }));
}

// ─── Lobby ────────────────────────────────────────────────────
function renderLobby(msg) {
  document.getElementById('lobby-code').textContent = msg.roomCode;
  document.getElementById('lobby-count').textContent = msg.players.length;

  const list = document.getElementById('lobby-players');
  list.innerHTML = msg.players.map(p => `
    <div class="lobby-player-row">
      <div class="player-dot"></div>
      <span>${p.name}</span>
      ${p.isHost ? '<span class="host-badge">Host</span>' : ''}
    </div>`).join('');

  const hostArea = document.getElementById('lobby-host-area');
  const waitArea = document.getElementById('lobby-wait-area');
  if (isHost) {
    hostArea.style.display = 'block';
    waitArea.style.display = 'none';
    document.getElementById('start-btn').disabled = msg.players.length < 2;
  } else {
    hostArea.style.display = 'none';
    waitArea.style.display = 'block';
  }
}

function startGame() {
  sendMsg({ type: 'start_game' });
}

function copyCode() {
  const code = document.getElementById('lobby-code').textContent;
  navigator.clipboard.writeText(code).then(() => {
    const btn = document.getElementById('copy-btn');
    btn.textContent = 'U kopjua ✓';
    setTimeout(() => btn.textContent = 'Kopjo kodin', 2000);
  });
}

// ─── Loja kryesore ────────────────────────────────────────────
function renderGame(state) {
  showPhase('game');

  // Chip-et e lartë
  const activePlayer = state.players.find(p => p.id === state.activePlayerId);
  const turnChip = document.getElementById('chip-turn');
  const isMyTurn = state.isMyTurn;
  turnChip.textContent = isMyTurn ? 'Radha jote!' : `Radha e: ${activePlayer?.name || '—'}`;
  turnChip.className = 'chip' + (isMyTurn ? ' my-turn' : '');
  document.getElementById('chip-room').textContent = `Dhoma: ${state.roomCode}`;

  // Mesazhi
  renderMsg(state);

  // Kundërshtarët
  renderOpponents(state);

  // Dora ime
  renderMyHand(state.myHand);

  // Log
  const logEl = document.getElementById('game-log');
  logEl.innerHTML = (state.log || []).map(l => `<div class="log-item">${l}</div>`).join('');
}

function renderMsg(state) {
  const msg = document.getElementById('game-msg');
  const drawFrom = state.opponents?.find(o => o.id === state.drawFromId);

  if (state.myHand?.length === 0) {
    msg.className = 'msg-box success';
    msg.textContent = 'Bravo! Ke dalë — prit të mbarojnë të tjerët.';
  } else if (state.isMyTurn && drawFrom) {
    msg.className = 'msg-box';
    msg.textContent = `Radha jote! Kliko mbi kartolat e "${drawFrom.name}" për të zgjedhur.`;
  } else if (state.isMyTurn && !state.drawFromId) {
    msg.className = 'msg-box success';
    msg.textContent = 'Mirë! Prit radhën tjetër.';
  } else {
    const active = state.players?.find(p => p.id === state.activePlayerId);
    msg.className = 'msg-box warn';
    msg.textContent = `${active?.name || '—'} po luan...`;
  }
}

function renderOpponents(state) {
  const area = document.getElementById('opponents-area');
  area.innerHTML = '';

  state.opponents.forEach(opp => {
    const isDrawable = state.isMyTurn && opp.id === state.drawFromId && opp.cardCount > 0;

    const row = document.createElement('div');
    row.className = 'opp-row';

    const cardsHtml = Array.from({ length: opp.cardCount }, (_, i) => {
      const cls = ['card-back'];
      if (isDrawable) cls.push('drawable');
      else cls.push('not-my-turn');
      const click = isDrawable ? `onclick="openDrawModal('${opp.id}', '${escHtml(opp.name)}', ${opp.cardCount})"` : '';
      return `<div class="${cls.join(' ')}" ${click} title="${isDrawable ? 'Kliko për të marrë' : ''}">♠</div>`;
    }).join('');

    const outBadge = opp.isOut ? '<span class="badge badge-out" style="margin-left:6px">✓ Doli</span>' : '';

    row.innerHTML = `
      <div class="opp-name">
        ${escHtml(opp.name)}
        ${outBadge}
        <div class="opp-meta">${opp.cardCount} letra</div>
      </div>
      <div class="opp-cards">${cardsHtml}</div>`;
    area.appendChild(row);
  });
}

function renderMyHand(hand) {
  const container = document.getElementById('my-hand');
  if (!hand || hand.length === 0) {
    container.innerHTML = '<span style="font-size:14px;color:#999">Ke dalë ✓</span>';
    return;
  }
  container.innerHTML = hand.map(card => {
    let cls = 'playing-card';
    if (card.isKerri)                    cls += ' kerri-card';
    else if (RED_SUITS.has(card.suit))   cls += ' red-card';
    else                                  cls += ' black-card';
    return `<div class="${cls}"><div class="rank">${card.rank}</div><div class="suit">${card.suit}</div></div>`;
  }).join('');
}

// ─── Modal: Zgjedh kartën nga kundërshtari ────────────────────
function openDrawModal(fromPlayerId, fromName, cardCount) {
  document.getElementById('modal-title').textContent = `Zgjedh një letër nga dora e ${fromName}`;

  // Shfaq kartolat e fshehura — lojtari zgjedh CILIN pozicion
  const container = document.getElementById('modal-cards');
  container.innerHTML = Array.from({ length: cardCount }, (_, i) => `
    <div class="playing-card drawable-card black-card" onclick="confirmDraw('${fromPlayerId}', ${i})">
      <div class="rank">♠</div>
      <div class="suit">${i + 1}</div>
    </div>`).join('');

  document.getElementById('draw-modal').style.display = 'flex';
  pendingDraw = { fromPlayerId };
}

function confirmDraw(fromPlayerId, cardIndex) {
  sendMsg({ type: 'draw_card', fromPlayerId, cardIndex });
  closeDrawModal();
}

function closeDrawModal() {
  document.getElementById('draw-modal').style.display = 'none';
  pendingDraw = null;
}

// ─── Fund loje ────────────────────────────────────────────────
function renderGameOver(msg) {
  showPhase('gameover');
  const isMe = msg.loserId === myId;
  document.getElementById('go-emoji').textContent = isMe ? '😱' : '🎉';
  document.getElementById('go-loser').textContent = msg.loserName;
  document.getElementById('go-sub').textContent =
    isMe ? 'Ty të ngeci Kerri!' : 'Atij/Asaj i ngeci Kerri!';

  document.getElementById('go-results').innerHTML = msg.results.map(r => {
    let badgeClass, badgeText;
    if (r.hasKerri)        { badgeClass = 'badge-kerri'; badgeText = '♠ Kerri'; }
    else if (r.cardCount === 0) { badgeClass = 'badge-out'; badgeText = '✓ Doli'; }
    else                        { badgeClass = 'badge-safe'; badgeText = `${r.cardCount} letra`; }
    return `
      <div class="result-row">
        <span>${escHtml(r.name)}</span>
        <span class="badge ${badgeClass}">${badgeText}</span>
      </div>`;
  }).join('');
}

function playAgain() {
  // Kthehu në lobby nëse je host, ose prisni
  sendMsg({ type: 'start_game' });
}

// ─── Chat ─────────────────────────────────────────────────────
function sendChat() {
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text) return;
  sendMsg({ type: 'chat', text });
  input.value = '';
}

function appendChat(msg) {
  const area = document.getElementById('chat-messages');
  const div = document.createElement('div');
  if (msg.system) {
    div.className = 'chat-msg system';
    div.textContent = msg.text;
  } else {
    div.className = 'chat-msg';
    div.innerHTML = `<span class="chat-sender">${escHtml(msg.sender)}:</span> ${escHtml(msg.text)}`;
  }
  area.appendChild(div);
  area.scrollTop = area.scrollHeight;
}

// ─── Ndihmëse ─────────────────────────────────────────────────
function showPhase(id) {
  document.querySelectorAll('.phase').forEach(p => p.classList.remove('active'));
  document.getElementById('phase-' + id).classList.add('active');
}

function showError(id, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = msg;
  el.style.display = 'block';
}

function hideError(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = 'none';
}

function escHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}
