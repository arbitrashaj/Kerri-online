# Kujt i ngec Kerri — Shumëlojtarësh Online

Lojë kartash shqiptare me shumë lojtarë në kohë reale (WebSocket).

---

## Si ta instalosh dhe nisësh

### Kërkesat
- [Node.js](https://nodejs.org) v16 ose më e re

### Hapat

```bash
# 1. Hyr në dosjen e projektit
cd kerri-online

# 2. Instalo bibliotekat
npm install

# 3. Nis serverin
npm start
```

Pastaj hap **http://localhost:3000** në shfletues.

---

## Si luhet online

1. **Lojtari i parë** fut emrin dhe klikon "Krijo dhomë të re"
2. Shfaqet kodi 4-shkronjësh — e.g. `A3BX`
3. **Të gjithë të tjerët** fusin emrin dhe kodin, klikojnë "Hyr"
4. Hosti klikon **"Fillo lojën"**
5. Secili sheh **letrat e veta** — kur vjen radha, zgjedh **cilën kartë** t'i marrë kundërshtarit

---

## Struktura e skedarëve

```
kerri-online/
├── server.js          ← Server Node.js (WebSocket + logjika e lojës)
├── package.json       ← Varësitë
├── README.md          ← Ky skedar
└── public/
    ├── index.html     ← Faqja kryesore (HTML)
    ├── style.css      ← Stilet
    └── client.js      ← Kodi i klientit (WebSocket + UI)
```

---

## Si ta publikosh falas online

### Railway (rekomandohet — 1 minutë)
1. Krijo llogari falas: https://railway.app
2. "New Project" → "Deploy from GitHub" (ngarko kodin në GitHub)
3. Railway e njeh automatikisht Node.js dhe nis serverin
4. Merr URL-në publike dhe ndajeni me miqtë!

### Render.com
1. Krijo llogari: https://render.com
2. "New Web Service" → lidhu me GitHub
3. Build Command: `npm install`
4. Start Command: `node server.js`

### Glitch.com (më i thjeshtë — drag & drop)
1. Shko tek https://glitch.com
2. "New Project" → "Import from GitHub"
3. Projekti niset automatikisht

### VPS (DigitalOcean, Hetzner, etj.)
```bash
# Instalo Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt-get install -y nodejs

# Ngarko skedarët dhe nis
npm install
node server.js

# Ose me PM2 (mban serverin aktiv gjithmonë)
npm install -g pm2
pm2 start server.js --name kerri
pm2 save
```

---

## Personalizimi

### Ndrysho ngjyrat
Hap `public/style.css` dhe modifiko variablat `:root {}` në fillim.

### Ndrysho shpejtësinë (nuk ka AI — të gjithë janë lojtarë njerëzorë)
Loja tani është 100% njerëzore — nuk ka AI.

### Shto lloje të reja Kerri
Në `server.js`, shto tek `KERRI_CONFIGS`:
```js
const KERRI_CONFIGS = {
  joker: { rank: '★', suit: '★' },
  queen: { rank: 'Q', suit: '♠' },
  ace:   { rank: 'A', suit: '♥' },
  // shto këtu:
  king:  { rank: 'K', suit: '♣' },
};
```
Pastaj shto opsionin në `public/index.html`:
```html
<option value="king">♣K Mbreti i Palave</option>
```

---

## Licenca
E lirë — projekti është plotësisht i yti!
